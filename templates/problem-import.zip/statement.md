# A+B Problem

Given two integers $A$ and $B$, output their sum.

## Input

One line with two integers.

## Output

One integer — the sum.
